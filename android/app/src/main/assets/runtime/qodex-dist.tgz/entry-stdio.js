import {
  ChannelServer,
  Emitter,
  IProviderProvisioningTargetService,
  IQodexAgentService,
  LoggingChannelServer,
  SocketProtocol,
  SourceServerWorkspaceIdentityChannelServer,
  VSBuffer,
  createQodexAgentConnectionScope,
  createServerHostServices,
  createTopicResourcePeers,
  getAppConfigDir,
  materializeBundledQodexBuiltinProviderConfig,
  readBundledQodexBuiltinProviderConfig,
  resolveHttpServerId
} from "./chunk-WKTKBKKE.js";
import "./chunk-FHIOQGYK.js";
import "./chunk-4VNS5WPM.js";

// src/stdio-log-guard.ts
var stderr = console.error.bind(console);
console.log = (...args) => stderr(...args);
console.info = (...args) => stderr(...args);

// src/entry-stdio.ts
import { randomUUID } from "node:crypto";
var log = (...args) => console.error(`[qodex-server:stdio] [${process.pid}]`, ...args);
function wrapProcessStdio() {
  const onData = new Emitter();
  const onClose = new Emitter();
  const onEnd = new Emitter();
  let finished = false;
  const finish = () => {
    if (finished) return;
    finished = true;
    onClose.fire();
    onEnd.fire();
  };
  process.stdin.on("data", (chunk) => {
    onData.fire(VSBuffer.wrap(new Uint8Array(chunk)));
  });
  process.stdin.on("end", finish);
  process.stdin.on("close", finish);
  process.stdin.on("error", (error) => {
    log("stdin error", error.message);
    finish();
  });
  process.stdout.on("error", (error) => {
    log("stdout error", error.code ?? error.message);
    process.exit(error.code === "EPIPE" ? 0 : 1);
  });
  return {
    onData: onData.event,
    onClose: onClose.event,
    onEnd: onEnd.event,
    write(buffer) {
      if (finished) return;
      process.stdout.write(Buffer.from(buffer.buffer));
    },
    end() {
      finish();
    },
    drain() {
      return Promise.resolve();
    },
    dispose() {
      finish();
    }
  };
}
function mountStdioChannelServer(services, workspaceIdentityMapper) {
  const socket = wrapProcessStdio();
  const protocol = new SocketProtocol(socket);
  const rawServer = new ChannelServer(protocol, "server");
  const loggedServer = new LoggingChannelServer(rawServer, log);
  const server = workspaceIdentityMapper ? new SourceServerWorkspaceIdentityChannelServer(loggedServer, workspaceIdentityMapper) : loggedServer;
  const agentService = services.getOptional(IQodexAgentService);
  const connectionScope = agentService ? createQodexAgentConnectionScope(agentService, {
    connectionId: `server-stdio-${randomUUID()}`,
    clientMode: "web-remote-replayable",
    role: "terminal-client"
  }) : void 0;
  const overrides = /* @__PURE__ */ new Map();
  if (connectionScope) {
    overrides.set(IQodexAgentService.channelName, connectionScope.service);
  }
  if (services.getOptional(IProviderProvisioningTargetService)) {
    overrides.set(IProviderProvisioningTargetService.channelName, {
      apply: async () => {
        throw new Error("Provider Provisioning \u4EC5\u652F\u6301\u53D7\u4FE1 Desktop Host");
      }
    });
  }
  services.exposeOnChannelServer(server, overrides);
  const disposeAll = () => {
    void connectionScope?.dispose();
    rawServer.dispose();
  };
  socket.onEnd(disposeAll);
  socket.onClose(disposeAll);
}
async function main() {
  const qodexBuiltinProviderConfigFilePath = await materializeBundledQodexBuiltinProviderConfig({
    environmentConfigRoot: getAppConfigDir(),
    content: readBundledQodexBuiltinProviderConfig()
  });
  const topicResourcePeers = createTopicResourcePeers();
  const serverId = resolveHttpServerId();
  const { services, workspaceIdentityMapper, migrationFailedPathCount } = await createServerHostServices({
    topicResourceRelayChannel: (request) => topicResourcePeers.getChannel(request),
    sourceServerId: serverId,
    qodexBuiltinProviderConfigFilePath
  });
  mountStdioChannelServer(services, workspaceIdentityMapper);
  if (migrationFailedPathCount > 0) {
    log(`workspace migration skipped ${migrationFailedPathCount} unreadable path(s)`);
  }
  log("RPC channel ready on stdio \u2014 waiting for host frames");
  log(`qodex builtin provider config: ${qodexBuiltinProviderConfigFilePath}`);
  const exitWhenPipeCloses = () => {
    log("stdin closed \u2014 exiting");
    process.exit(0);
  };
  process.stdin.on("end", exitWhenPipeCloses);
  process.stdin.on("close", exitWhenPipeCloses);
  process.on("SIGTERM", exitWhenPipeCloses);
  process.on("SIGINT", exitWhenPipeCloses);
}
void main().catch((error) => {
  console.error("[qodex-server:stdio] startup failed", error);
  process.exitCode = 1;
});
