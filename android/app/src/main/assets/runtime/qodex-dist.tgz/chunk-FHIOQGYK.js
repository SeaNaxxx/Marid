// ../qodex-cua/broker.js
import { randomUUID } from "node:crypto";
import { tmpdir } from "node:os";
import { join } from "node:path";

// ../qodex-cua/broker-helper-constants.js
var HELPER_APP_NAME = "Qodex Computer Use.app";
var DEV_HELPER_APP_NAME = "Qodex Computer Use Dev.app";
var HELPER_GHOST_CURSOR_OVERLAY_ARG = "--ghost-cursor-overlay";

// ../qodex-cua/broker.js
var BROKER_SOCKET_ENV = "QODEX_CUA_PERMISSION_BROKER_SOCKET";
var BROKER_UNAVAILABLE_ENV = "QODEX_CUA_PERMISSION_BROKER_UNAVAILABLE";
var BrokerError = class extends Error {
  constructor(message, options = {}) {
    super(message ?? "Computer Use broker is unavailable.");
    this.name = "BrokerError";
    this.code = options.code ?? "unavailable";
    if (options.details !== void 0) this.details = options.details;
  }
};
var CuaHelperError = class extends Error {
  constructor(message, options = {}) {
    super(message ?? "Computer Use Helper is unavailable.");
    this.name = "CuaHelperError";
    this.code = options.code ?? "helper_unavailable";
  }
};
var brokerErrorFactory = (code) => (message, details) => new BrokerError(message ?? code, { code, details });
var notAuthorized = brokerErrorFactory("not_authorized");
var notSelectable = brokerErrorFactory("not_selectable");
var notSettable = brokerErrorFactory("not_settable");
var elementUnavailable = brokerErrorFactory("element_unavailable");
var actionUnavailable = brokerErrorFactory("action_unavailable");
var foregroundRequired = brokerErrorFactory("foreground_required");
async function callBrokerMethod(_args) {
  throw new BrokerError("Computer Use is not available in this build.");
}
async function probeHelperHealth(_socketPath, _options) {
  return { bundleId: null, pid: null };
}
function mintBrokerSocketPath(options = {}) {
  const dir = typeof options.dir === "string" ? options.dir : tmpdir();
  return join(dir, `qodex-cua-broker-${randomUUID()}.sock`);
}
function resolveBrokerSocketPath(options = {}) {
  const env = options.env ?? process.env;
  const fromEnv = env[BROKER_SOCKET_ENV];
  if (typeof fromEnv === "string" && fromEnv.trim()) return fromEnv;
  return mintBrokerSocketPath(options);
}

export {
  HELPER_APP_NAME,
  DEV_HELPER_APP_NAME,
  HELPER_GHOST_CURSOR_OVERLAY_ARG,
  BROKER_SOCKET_ENV,
  BROKER_UNAVAILABLE_ENV,
  CuaHelperError,
  callBrokerMethod,
  probeHelperHealth,
  mintBrokerSocketPath,
  resolveBrokerSocketPath
};
