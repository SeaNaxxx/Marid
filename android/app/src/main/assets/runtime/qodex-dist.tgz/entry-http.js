import {
  createHttpServer,
  createServerHostServices,
  createTopicResourcePeers,
  getAppConfigDir,
  materializeBundledQodexBuiltinProviderConfig,
  readBundledQodexBuiltinProviderConfig,
  resolveHttpServerId
} from "./chunk-WKTKBKKE.js";
import "./chunk-FHIOQGYK.js";
import "./chunk-4VNS5WPM.js";

// src/entry-http.ts
async function main() {
  const qodexBuiltinProviderConfigFilePath = await materializeBundledQodexBuiltinProviderConfig({
    environmentConfigRoot: getAppConfigDir(),
    content: readBundledQodexBuiltinProviderConfig()
  });
  const port = Number(process.env["PORT"]) || 3030;
  const host = process.env["QODEX_SERVER_HOST"]?.trim() || process.env["HOST"]?.trim() || void 0;
  const staticRoot = process.env["QODEX_WEB_STATIC_ROOT"]?.trim() || void 0;
  const authToken = process.env["QODEX_SERVER_AUTH_TOKEN"]?.trim() || void 0;
  const topicResourcePeers = createTopicResourcePeers();
  const serverId = resolveHttpServerId();
  const { services, workspaceIdentityMapper, migrationFailedPathCount } = await createServerHostServices({
    topicResourceRelayChannel: (request) => topicResourcePeers.getChannel(request),
    sourceServerId: serverId,
    qodexBuiltinProviderConfigFilePath,
    providerProvisioningTargetEnabled: Boolean(authToken)
  });
  createHttpServer(services, port, {
    serverId,
    workspaceIdentityMapper,
    migrationFailedPathCount,
    virtualProjects: true,
    topicResourcePeers,
    ...host ? { host } : {},
    ...staticRoot ? { staticRoot, spaFallback: true } : {},
    ...authToken ? { authToken, authRequired: true } : {}
  });
}
void main().catch((error) => {
  console.error("[qodex-server:http] startup failed", error);
  process.exitCode = 1;
});
